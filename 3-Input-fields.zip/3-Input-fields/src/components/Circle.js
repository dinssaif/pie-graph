import React from "react";

function Circle(props) {
  return <div style={props.styles} className="circle"></div>;
}

export default Circle;
