import React from "react";

function Line(props) {
  return <div style={props.styles}></div>;
}

export default Line;
